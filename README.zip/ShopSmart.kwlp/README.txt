Klocwork local project
