package com.yuvrajsinghgmx.shopsmart.ApiData

data class Pics(
    val hits: List<Hit>,
    val total: Int,
    val totalHits: Int
)