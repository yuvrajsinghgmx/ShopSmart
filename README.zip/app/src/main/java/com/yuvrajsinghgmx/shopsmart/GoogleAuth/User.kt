package com.yuvrajsinghgmx.shopsmart.GoogleAuth

data class User(
    var id: String = "",
    val name: String = "",
    val photoUrl: String = "",
    val email: String = "",
)
